console.log("Hi world");
var foo=0;
var bar=0;
if(bar==0){

console.log("You cant divide us!");

}
else{
console.log(foo/bar);

}



function dividefunction(){
console.log("divide");
}
