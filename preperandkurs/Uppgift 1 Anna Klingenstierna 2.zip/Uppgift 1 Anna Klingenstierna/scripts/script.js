//kommentar- datorn ignonerar detta
// variabel är en behållare, kan bara innehålla 1 sak 

alert ("You can´t divide us!")

let foo = 0
let bar = 0 
console.log ( foo/bar ) 

if (foo/bar != NaN) {
  console.log ("You cant´t divide us")
}
  