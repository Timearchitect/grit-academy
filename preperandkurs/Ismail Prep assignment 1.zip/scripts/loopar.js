// while har påståenden conditions är det sant så loopar den
// är det falskt så stoppar den 
let counter = 0;  // deklarerar

while(counter < 10){  // condition
    counter +=  1;  // inkremeterar
    console.log("loop: "+ counter);
    document.write('<img src="pictures/flower1.jpeg" alt="this is a flower" width="400" height="300">');
}

// 1) deklaration av variabel  ;
// 2) condition påstående      ;
// 3) variabeln increment / ändra på sig
for( let count = 10  ;  count < 15  ;  count = count + 3  ){
    console.log("loop: "+ count);
    document.write('<img src="pictures/flower1.jpeg" alt="this is a flower" width="400" height="300">');
}


let que = ["alrik","lisa","henrik","robin","emma","noel","kalle","ben"];
// count = count+1;   //5 tecken
// count += 1;        //4 tecken
// count ++;          //3 tecken ökar +1



// let sitter inne ,ok att deklarera med samma namn utanför
/*for( var i = 0  ;  i < que.length ;  i++  ){
    console.log( que[i] );
}*/

