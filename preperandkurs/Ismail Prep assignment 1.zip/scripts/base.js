/*let foo = 4;
let duarvuxen = true;  
// < > <= mindre än &  likamed >= ,  !=   inte likamed
// ! not


//console.log(!8);

if(foo < 10)
    console.log("alt 1");
else if(foo < 5)
    console.log("alt 2");
else
    console.log("alla regeler sa att det var falska");
       

if(foo < 10){
 console.log("alt 1");
}
else{ 
    if(foo < 5){
        console.log("alt 2");
    }
    else{
        console.log("alla regeler sa att det var falska");
    }
}



// && och/and   || eller/or
let VIP = false , haveDrugs = false;
let age = 14;


if(haveDrugs==false){
    if(VIP==true){
        console.log("du får komma in till klubben!!");
    }else if(age >= 18){
        console.log("du får komma in till klubben!!");
    }else{ 
        console.log("NEJ!!");
        console.log("NEJ!!");
        console.log("NEJ!!");
        console.log("NEJ!!");
    }
}else{
     console.log("polise!!");
} 
console.log("unskippable");


//    false     eller

if( false && false || true ){
    console.log("SANT");
}else{
    console.log("FALSKT");
}


*/