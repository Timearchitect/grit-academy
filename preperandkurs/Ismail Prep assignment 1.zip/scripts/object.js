//deklarationer av saker

let foo1 = 5;

let foo2 = [1,2,45,2,2,5,5,56];

let foo3 = {
    name: "alrik",
    color: "red",
    value: 5,
    isAlive: true,
    array: [1,2,4,2,3]
} 

let alriksConsole={
    log: function(x){ 
        console.log(x);
    }
}

function foo4(){

}

