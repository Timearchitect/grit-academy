
/*

//function
alert("hello");

//method
console.log("hello");

//deklarera en variabel
//foo = 0;    andvändning


//deklarera en funktion
//myFuction();  andvändning: call myFunction

function myFunction( name ){
    //let namn = "Alrik";
    console.log("funktionen tillhör: " + namn);
}


function addition( a , b){
    let result = a + b;
    //console.log("Resultatet är: " + result);
    return result;
}

let foo;
foo = addition(2,2);
console.log("foo är: "+ foo);

if(addition(2,2) == 4){
    console.log("sant");
}else {
    console.log("falsk");
}


function infinity(){
    alert("infinity");
    console.log("infinity");
    beyond();
}

function beyond(){
    alert("beyond");
    console.log("beyond");
    infinity();
}*/