alert("You cant divide us")

console.log("Foo");
console.log("bar");
let foo = 0;
let bar = 0;
let result = foo / bar;
console.log(foo/bar)

//borde väl vara typ alert.if men får det inte att funka