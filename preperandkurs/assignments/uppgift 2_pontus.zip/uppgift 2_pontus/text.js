var age = document.getElementById("age");
var vip = document.getElementById("vip");

function checkAge(){
    if (age >= 18 && vip.checked== false){ alert = "welcome!";
       }
    else (age <= 17 && vip.checked== false) ;alert = "Access denied"
        
}

{
    if (vip.checked == true){ alert = "Welcome in my best VIP customer";
       }
    else (vip.checked == false) ;alert = "Start spending money"
        
    }


   





