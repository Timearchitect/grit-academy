//alert("You cant divide us!");
document.write("Kitty world");



let foo = 0;
let bar = 0;

console.log ( foo );
console.log ( bar );

console.log ( foo / bar );

//osäker på hur jag ska skapa en alert när den inte producerat ett nummer
if ( foo / bar ) { alert("You can't divide us!"); }
if (Number === "0") {
    text = "You cant divide us!";}