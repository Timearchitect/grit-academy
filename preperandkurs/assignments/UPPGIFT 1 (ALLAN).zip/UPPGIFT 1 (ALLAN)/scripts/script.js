let foo = 0
let bar = 0