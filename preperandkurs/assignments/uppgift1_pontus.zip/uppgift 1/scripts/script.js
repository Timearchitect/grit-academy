alert ("you cant divide us")

let namn = "divide";
console.log (namn)

let foo;
foo = 0

let bar;
bar = 0

console.log ( foo / bar);

