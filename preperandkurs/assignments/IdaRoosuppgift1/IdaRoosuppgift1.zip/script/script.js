



document.write("Hello!");

let divide = "divide";


let foo;

foo = 0;

let bar = 0;

console.log( foo / bar);

if (foo / bar == NaN)
 {

  alert("You cant divide us!");
}
