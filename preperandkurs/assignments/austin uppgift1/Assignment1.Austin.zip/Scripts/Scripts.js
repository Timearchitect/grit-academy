function calldivide(){
    console.log("divide")
}

let foo = 0;
let bar = 0;

let result = foo / bar;

// if result equals to 0 or result exist
if(result == 0 || result){
    console.log("result = " + result)
}
else{   //else did not get any result (result = bar / foo)
    console.log("Cannot divide us")
}

