
// 1 - Variable of datatype Boolean

    let vip = true


// 2 - Declare variable "age" assigned number 17

    let age = 17


/* 3 -  Assign variable age from the inputbox's value instead
        Assign vip with the checkbox's value.
    */


/* 4 -  Make a if-statement with:
        when its true, shows a alertsbox with "Access granted"
        when its false, shows a alertsbox with "Access denied"
        Make a condition that outputs true if age is over or equal to 18.
    */

/*
    if (age >= 18)
    alert("Access granted")
    else
    alert("Access denied")
*/


/* 5 -  Add one more if-statement for the variable vip:
        In case its true, just say "Welcome in my best VIP customer :)" and skip asking about the age */

        if
        (vip == true)
        alert("Welcome in my best VIP customer :)")

        else
        {
        if (age >= 18)
        alert("Access granted")
        else
        alert("Access denied")
        }