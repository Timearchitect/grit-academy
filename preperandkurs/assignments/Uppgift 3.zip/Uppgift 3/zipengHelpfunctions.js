//uppgift 3a

function charRemove(char, str) {

    if (typeof char != "string" && char.length == 1) {

        console.warn("Wrong param")

        return str
    }

    if (typeof str != "string") {

        console.warn("Wrong param")

        return str
    }

    let newStr = ""

    for (let i = 0; i < str.length; i++) {

        if (str[i] != char) {

            newStr = newStr + str[i]
        }
    }

    return newStr
}
