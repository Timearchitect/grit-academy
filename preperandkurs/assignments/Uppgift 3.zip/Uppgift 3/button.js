const button = document.getElementById("button")

const cat = {
    alive: true,
    name: "gustav"
}

button.addEventListener("click", () => {
    alert("This cats name is " + cat.name)  
})