//alert("Hej");
/*  Uppgift 1
    document.write("HEJ");
    console.log("Bonjour!!!");
*/

// Variabler


// Variabel 1) 
let foo;

// foo tilldela med siffran 0
foo = 0;

// Variabel 2)
let bar;

// bar tilldela med siffran 0
bar = 0;

console.log (10*10);


 