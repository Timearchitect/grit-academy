

alert(Youcantdivideus);

var foo = 0;
var bar = 0;
console.log (foo/bar);

