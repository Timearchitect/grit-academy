function charRemove (char , text){
    console.log (text.replaceAll(char , ""));
}

charRemove ("p" , "pontus")


        






      


