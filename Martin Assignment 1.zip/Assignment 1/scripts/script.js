
// Declare two variables and assign them each the value 0
let foo = 0;
let bar = 0;

// Make the script perform division of these variables and show it on the browser control log
console.log(foo / bar);

// Make a statement that alerts with "You can't divide us!" if the results doesn't produse a number


// Inject button with javascript that displays "divide" on the console log when you click the button
let divide = "divide";