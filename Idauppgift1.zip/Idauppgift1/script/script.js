alert("Tjena!!");



document.write("HELLO");
console.log("hello world");


let foo;

foo = 0;

let bar = 0;

console.log( foo / bar);
